// Cal eProcure — Open Bids (listings + per-event enrichment) scraper.
//
// Drives the InFlight/PeopleSoft SPA at caleprocure.ca.gov:
//   1. Runs the public "Posted" (open) event search and extracts every distinct
//      bid from the results grid.
//   2. For each event, deep-links directly to the public event detail page
//      (https://caleprocure.ca.gov/event/{BU}/{eventId}) — the only way to reach
//      event details + attachments anonymously (clicking the grid does nothing
//      without a session, and the bid-comments page 403s on a direct GET).
//   3. From the detail page it harvests the full description, real end date,
//      buyer contact, UNSPSC codes and service-area counties, then opens
//      "View Event Package" to read the attachments table (file name +
//      description) from the bid-comments page.
//
// The {BU} (PeopleSoft Business Unit) is NOT exposed anywhere in the anonymous
// listing, so we map the event's department name → BU via DEPT_BU below. Events
// whose department we can't map (e.g. the "DGS - Statewide Procurement"
// aggregator) are still emitted from the listing, just without enrichment.
//
// Attachment *download* URLs are session-bound (/psc/.../viewredirect/{V2}…) and
// expire, so we deliberately store only the file name + description and link the
// user to the durable /event/{BU}/{eventId} page to download.
//
// Output item:
//   { eventId, name, department, endRaw, endDate, status, url,
//     description, contactEmail, unspscCodes[], counties[], attachments[] }

import { Actor } from 'apify';
import { chromium } from 'playwright';

const SEARCH_URL = 'https://caleprocure.ca.gov/pages/Events-BS3/event-search.aspx';
const UA =
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36';

// Department display name (lower-cased) → PeopleSoft Business Unit code. Kept in
// sync with src/app/api/caleprocure/[eventId]/route.ts. Used to build the public
// deep link /event/{BU}/{eventId}.
const DEPT_BU = {
  '22nd daa': '8540',
  'business & economic developmnt': '0509',
  'ca arts council': '8260',
  'ca conservation corps': '3340',
  'ca health benefit exchange': '4800',
  'ca school finance authority': '0985',
  'ca tahoe conservancy': '3125',
  'cal fire': '3540',
  'csu, bakersfield': '6610',
  'csu, channel islands': '6610',
  'csu channel islands': '6610',
  'csu, dominguez hills': '6610',
  'csu, east bay': '6610',
  'csu, fresno': '6610',
  'csu, fullerton': '6610',
  'csu, sacramento': '6610',
  'csu, san bernardino': '6610',
  'csu, san diego': '6610',
  'csu, sonoma': '6610',
  'correctional trng rehab aut': '5225',
  'dgs - statewide procurement': '7760',
  'department of cannabis control': '1111',
  'department of conservation': '3480',
  'department of consumer affairs': '1111',
  'department of education': '6100',
  'department of fish & wildlife': '3600',
  'department of general services': '7760',
  'department of human resources': '8380',
  'department of insurance': '0845',
  'department of justice': '0820',
  'department of motor vehicles': '2740',
  'department of public health': '4265',
  'department of rehabilitation': '5160',
  'department of social services': '5180',
  'department of state hospitals': '4440',
  'department of technology': '7502',
  'department of transportation': '2660',
  caltrans: '2660',
  'department of water resources': '3860',
  'dept of corrections & rehab': '5225',
  'dept of developmental services': '4300',
  'dept of food & agriculture': '8570',
  'department of food and agriculture': '8570',
  'dept of industrial relations': '7350',
  'dept of managed health care': '4150',
  'dept of parks & recreation': '3790',
  'dept of pesticide regulation': '3930',
  'dept of tax and fee admin': '7600',
  'dept of veterans affairs': '8955',
  'dept of the ca highway patrol': '2720',
  'california highway patrol': '2720',
  'dept. alcoholic beverage cntrl': '2100',
  'dept. toxic substances control': '3960',
  'employment development dept': '7100',
  'energy resources conservation': '3360',
  "env'l health hazard assessment": '3980',
  'exposition park': '3100',
  'first 5 california': '4250',
  'franchise tax board': '7730',
  'gov ofc serv and community eng': '0650',
  "gov's off of lnd use & clmt in": '0650',
  'hope for children trust acct': '0950',
  'high speed rail authority': '2665',
  'institute for regenerative med': '6445',
  'judicial branch': '0250',
  'military department': '8940',
  'ofc technology and solutions i': '0531',
  'office of emergency services': '0690',
  'office of energy infrastructur': '3355',
  'office of exposition park': '3100',
  "public employees' retirement": '7900',
  'public employees retirement': '7900',
  'public utilities commission': '8660',
  'sf bay conservation commission': '3820',
  'school for the deaf-riverside': '6100',
  'state air resources board': '3900',
  'state board of equalization': '0860',
  'state coastal conservancy': '3760',
  'state controller': '0840',
  'state dept hlth care services': '4260',
  "state teachers' retirement sys": '7920',
  'state water resources control': '3940',
  'statewide stpd': '7502',
  'superior court of san bernardi': '0250',
  'uc davis medical center': '6440',
  'uc santa cruz': '6440',
  ucla: '6440',
};

function buFor(dept) {
  return DEPT_BU[String(dept || '').trim().toLowerCase()] || null;
}

/** Parse "06/08/2026 8:00AM PDT" style strings into ISO. */
function parseEnd(raw) {
  if (!raw) return null;
  const m = String(raw).match(/(\d{2}\/\d{2}\/\d{4})\s*(.*)$/);
  if (!m) return null;
  const [, date, time] = m;
  const d = new Date(`${date} ${time}`.replace(/\s+/g, ' ').trim());
  if (!isNaN(d.getTime())) return d.toISOString();
  const d2 = new Date(date);
  return isNaN(d2.getTime()) ? null : d2.toISOString();
}

/**
 * Enrich one event by deep-linking to its public detail page and reading the
 * attachments off the Event Package / bid-comments page. Returns the extra
 * fields to merge onto the listing item. Best-effort: any failure (unknown BU,
 * PeopleSoft error page, timeout) returns an empty enrichment so the listing row
 * is still emitted.
 */
async function enrichEvent(ctx, item) {
  const eventId = String(item.eventId || '').trim();
  const bu = buFor(item.department);
  const empty = { url: null, description: null, contactEmail: null, unspscCodes: [], counties: [], attachments: [] };
  if (!eventId || !bu) return empty;

  const url = `https://caleprocure.ca.gov/event/${bu}/${encodeURIComponent(eventId)}`;
  const page = await ctx.newPage();
  try {
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 45000 }).catch(() => {});
    // Wait for either the detail page to render or an error page to settle.
    await page
      .waitForSelector('#RESP_INQ_DL0_WK_AUC_DOWNLOAD_PB, #unspscTable, #serviceAreaTable', { timeout: 20000 })
      .catch(() => {});
    await page.waitForTimeout(1500);

    if (/error\.aspx/.test(page.url())) {
      await page.close();
      return empty; // BU resolved to the wrong unit for this event.
    }

    // Rich detail fields from the event details page.
    const detail = await page.evaluate(() => {
      const t = document.body.innerText || '';
      const descM = t.match(
        /Description:\s*\n+([\s\S]*?)\n(?:View Event Package|View Vendor Ads|Contact Information|UNSPSC|Pre Bid|Contractor License)/i
      );
      const endM = t.match(/Event End Date:\s*\n+([^\n]+)/i);
      const emailM = t.match(/[\w.+-]+@[\w.-]+\.\w{2,}/);
      const unspsc = [...document.querySelectorAll('#unspscTable tr')]
        .slice(1)
        .map((r) => {
          const c = [...r.querySelectorAll('td')].map((x) => (x.textContent || '').trim());
          return c[0] ? c[0] : null;
        })
        .filter(Boolean);
      const counties = [...document.querySelectorAll('#serviceAreaTable tr')]
        .slice(1)
        .map((r) => {
          const c = [...r.querySelectorAll('td')].map((x) => (x.textContent || '').trim());
          return c[1] || null;
        })
        .filter(Boolean);
      return {
        description: descM ? descM[1].trim().replace(/\s+/g, ' ') : null,
        endRaw: endM ? endM[1].trim() : null,
        contactEmail: emailM ? emailM[0] : null,
        unspscCodes: unspsc,
        counties,
      };
    });

    // Open "View Event Package" → bid-comments page → attachments table.
    let attachments = [];
    const pkg = page.locator('#RESP_INQ_DL0_WK_AUC_DOWNLOAD_PB');
    if (await pkg.count().catch(() => 0)) {
      await pkg.click({ timeout: 12000, force: true }).catch(() => {});
      await page.waitForLoadState('domcontentloaded', { timeout: 15000 }).catch(() => {});
      await page
        .waitForSelector('[id^="PV_ATTACH_WRK_SCM_DOWNLOAD$"], [name="ViewAttachmentsFileName"]', { timeout: 12000 })
        .catch(() => {});
      await page.waitForTimeout(1500);
      attachments = await page.evaluate(() => {
        const names = [...document.querySelectorAll('[name="ViewAttachmentsFileName"]')];
        const out = [];
        names.forEach((nameEl, i) => {
          const name = (nameEl.textContent || '').trim();
          if (!name) return;
          const descEl = document.querySelector(`#PV_ATTACH_WRK_ATTACH_DESCR\\$${i}`);
          const description = descEl ? (descEl.value || descEl.textContent || '').trim() : '';
          // No durable URL: the PeopleSoft download link is session-bound and
          // expires. The UI links to the event page (item.url) instead.
          out.push({ name, description, url: '' });
        });
        return out;
      });
    }

    await page.close();
    return {
      url,
      description: detail.description,
      contactEmail: detail.contactEmail,
      unspscCodes: detail.unspscCodes,
      counties: detail.counties,
      // Prefer the detail-page end date (authoritative) over the listing's.
      endRaw: detail.endRaw || item.endRaw,
      attachments,
    };
  } catch (e) {
    console.warn(`enrich ${eventId} failed: ${e.message}`);
    await page.close().catch(() => {});
    return empty;
  }
}

/** Run async tasks over `items` with a fixed concurrency. */
async function mapPool(items, concurrency, worker) {
  const results = new Array(items.length);
  let next = 0;
  const runners = Array.from({ length: Math.max(1, concurrency) }, async () => {
    while (true) {
      const i = next++;
      if (i >= items.length) break;
      results[i] = await worker(items[i], i);
    }
  });
  await Promise.all(runners);
  return results;
}

await Actor.init();

const input = (await Actor.getInput()) || {};
const status = input.status || 'P'; // P = Posted (open), H = Historical
const keyword = (input.keyword || '').trim();
const limit = Number.isFinite(input.limit) ? input.limit : 0; // 0 = no cap
const concurrency = Number.isFinite(input.concurrency) && input.concurrency > 0 ? input.concurrency : 5;
const skipEnrich = !!input.skipEnrich;
// Cap how many of the listed events get the (slow) per-event enrichment. 0 = all.
const enrichLimit = Number.isFinite(input.enrichLimit) ? input.enrichLimit : 0;

try {
  console.log('Launching Chromium…');
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ userAgent: UA });
  const page = await ctx.newPage();

  console.log('Loading Cal eProcure event search…');
  await page.goto(SEARCH_URL, { waitUntil: 'networkidle', timeout: 60000 }).catch(() => {});
  await page.waitForTimeout(3000);

  await page.selectOption('#RESP_INQA_WK_ZZ_EVENT_STATUS', status).catch(() => {});
  if (keyword) {
    await page.fill('#RESP_INQA_WK_ZZ_AUC_NAME', keyword).catch(() => {});
  }
  await page
    .click('#RESP_INQA_WK_INQ_AUC_GO_PB', { timeout: 20000 })
    .catch((e) => console.warn(`search click: ${e.message}`));
  await page.waitForLoadState('networkidle', { timeout: 30000 }).catch(() => {});
  await page.waitForTimeout(7000);

  // Extract the results grid (distinct events).
  let items = await page.evaluate(() => {
    const grid = [...document.querySelectorAll('table')].sort(
      (a, b) => b.querySelectorAll('tr').length - a.querySelectorAll('tr').length
    )[0];
    if (!grid) return [];
    const out = [];
    for (const r of grid.querySelectorAll('tr')) {
      const cells = [...r.querySelectorAll('td')].map((x) => (x.textContent || '').trim()).filter(Boolean);
      if (cells.length >= 5 && /^[A-Za-z0-9-]+$/.test(cells[0]) && cells[0] !== 'Event ID') {
        out.push({
          eventId: cells[0],
          name: cells[1],
          department: cells[2],
          endRaw: cells[3],
          status: cells[cells.length - 1],
        });
      }
    }
    return [...new Map(out.map((o) => [o.eventId, o])).values()];
  });
  await page.close();

  // Apply keyword/limit to the listing up front so we never enrich rows we'll drop.
  if (keyword) {
    const re = new RegExp(keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
    items = items.filter((r) => re.test(r.name));
  }
  if (limit > 0) items = items.slice(0, limit);

  console.log(`Listing extracted: ${items.length} distinct ${status === 'P' ? 'open ' : ''}bids.`);

  // Decide which items get enriched (the rest are emitted listing-only).
  const enrichCount = skipEnrich ? 0 : enrichLimit > 0 ? Math.min(enrichLimit, items.length) : items.length;
  const toEnrich = items.slice(0, enrichCount);
  const listingOnly = items.slice(enrichCount);

  let withAttachments = 0;
  let enriched = 0;

  if (toEnrich.length) {
    console.log(`Enriching ${toEnrich.length} events (concurrency ${concurrency})…`);
    await mapPool(toEnrich, concurrency, async (item) => {
      const ex = await enrichEvent(ctx, item);
      const finalResult = {
        ...item,
        name: String(item.name || '').replace(/\s+/g, ' ').replace(/¿/g, '-').trim(),
        endRaw: ex.endRaw || item.endRaw,
        endDate: parseEnd(ex.endRaw || item.endRaw),
        url: ex.url || SEARCH_URL,
        description: ex.description || null,
        contactEmail: ex.contactEmail || null,
        unspscCodes: ex.unspscCodes || [],
        counties: ex.counties || [],
        attachments: ex.attachments || [],
      };
      if (finalResult.attachments.length) withAttachments++;
      enriched++;
      await Actor.pushData(finalResult);
      if (enriched % 25 === 0) console.log(`  …${enriched}/${toEnrich.length} enriched`);
    });
  }

  for (const item of listingOnly) {
    await Actor.pushData({
      ...item,
      name: String(item.name || '').replace(/\s+/g, ' ').replace(/¿/g, '-').trim(),
      endDate: parseEnd(item.endRaw),
      url: SEARCH_URL,
      description: null,
      contactEmail: null,
      unspscCodes: [],
      counties: [],
      attachments: [],
    });
  }

  console.log(
    `Done: ${items.length} bids (${enriched} enriched, ${withAttachments} with attachments, ${listingOnly.length} listing-only).`
  );
  await browser.close();
  await Actor.exit(`Done: ${items.length} bids; ${withAttachments} with attachments.`);
} catch (err) {
  console.error('Scrape failed:', err?.stack || err);
  await Actor.fail(`Scrape failed: ${err?.message || err}`);
}
